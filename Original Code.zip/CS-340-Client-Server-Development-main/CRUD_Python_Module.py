# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'AAC123' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None and isinstance(data, dict): 
            self.database.animals.insert_one(data)  # data should be dictionary
            return True
        else: 
            return False

    # Create method to implement the R in CRUD.
    def read(self, query):
        if query is not None and isinstance(query, dict):
            try:
                cursor = self.database.animals.find(query)  # Execute the query
                return list(cursor)
            except Exception as e:
                return []
        else:
            return []
            
    # Update method to implement the U in CRUD.
    def update(self, query, update_data):
        if query is not None and update_data is not None and isinstance(query, dict) and isinstance(update_data, dict):
            try:
                result = self.database.animals.update_many(query, {"$set": update_data}) # Update the record
                return result.modified_count
            except Exception as e:
                print(f"An error occurred during update: {e}")
                return 0
        else:
            return 0
    

            
    # Delete method to implement the D in CRUD.
    def delete(self, query): 
        if query is not None and isinstance(query, dict):
            try:
                result = self.database.animals.delete_many(query) # Delete the record
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred during delete: {e}")
                return 0 
        else:
            return 0

            